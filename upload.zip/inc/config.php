<?php


			/**************************************************************************************************
			| 
			| Shrinky - Free URL Shortener php script
			| by: Hassan
			|
			|**************************************************************************************************
			|
			| By using this software you agree that you do not have the right to sell it .
			|
			| Website: http://script.cr.ma
			|
			| Version: 2.0 
			|**************************************************************************************************/


            //error_reporting(E_ALL);
            ini_set('display_errors', '0');
            
                       
            // database 
            define ('MYSQL_USERNAME', 'Username');
            define ('MYSQL_PASSWORD', 'Password');
            define ('MYSQL_DATABASE', 'Database');
            define ('MYSQL_HOST',     'localhost');